<?php

/***************************************************************
 * Extension Manager/Repository config file for ext "gosuits".
 *
 * Auto generated 11-03-2013 18:03
 *
 * Manual updates:
 * Only the data in the array - everything else is removed by next
 * writing. "version" and "dependencies" must not be touched!
 ***************************************************************/

$extensionClassesPath = t3lib_extMgm::extPath('gosuits').'Classes/';
$default = array(
	'tx_gosuits_tca' => $extensionClassesPath.'class.tx_gosuits_tca.php',
);
return $default;

?>
