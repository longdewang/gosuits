<?php
	class Tx_Gosuits_Domain_Repository_GoGameRepository 
		extends Tx_Extbase_Persistence_Repository {}
?>
