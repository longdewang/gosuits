<?php
	class Tx_Gosuits_Domain_Model_GoGameFile extends Tx_Gosuits_Domain_Model_GoGame {}
?>
